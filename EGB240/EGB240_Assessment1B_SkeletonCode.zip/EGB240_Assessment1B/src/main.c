#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

void init() {
	cli();  //Disable interrupts

	//Set sysclk to 16 MHz
	CLKPR = 0x80; // Prescaler change enable
	CLKPR = 0x00; // Set prescaler to zero

	//Configure PORT D4-D7 (LEDs) as outputs
	PORTD = 0x00;
	DDRD = 0xF0;

	sei();  //Enable interrupts
}

int main(void) {

	// Initialisation
	init();

	// Main loop (loop forever)
	for(;;) {
		// 1 Hz flash on LED4 (white)
		PORTD ^= 0x80;	// Toggle LED4
		_delay_ms(500);	// 500ms delay
	}
}